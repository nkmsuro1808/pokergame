Poker
=====

A poker application running on node.js with socket.io, using angularJS on the front-end for data binding.

View a demo of the work in progress [here](http://dev.tableflippoker.com/)